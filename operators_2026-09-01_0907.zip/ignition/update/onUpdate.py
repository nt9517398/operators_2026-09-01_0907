def onUpdate(actor, resources):
	