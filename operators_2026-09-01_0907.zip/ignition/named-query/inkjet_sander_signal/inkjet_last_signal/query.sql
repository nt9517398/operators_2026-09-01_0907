SELECT t_stamp
FROM inkjet_signal
ORDER BY t_stamp DESC
LIMIT 1;