SELECT *
FROM inkjet_signal
ORDER BY t_stamp DESC
LIMIT 25;