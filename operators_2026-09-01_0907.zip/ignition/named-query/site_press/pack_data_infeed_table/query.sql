SELECT TOP 1
    pileId,
    thickness,
    length,
    width,
    billetCount,
    billetVolume,
    pilechangetime AS pilechangetime_utc,
    CAST(
        pilechangetime AT TIME ZONE 'UTC'
        AT TIME ZONE 'AUS Eastern Standard Time'
        AS datetime
    ) AS pilechangetime_melbourne
FROM Layup_Billet_Stacks_Minute15
WHERE pileId = :eventId_value 
ORDER BY pilechangetime DESC;

