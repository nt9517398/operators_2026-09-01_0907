SELECT
    date_trunc('hour', t_stamp) AS hour_bucket,
    COUNT(*) AS entry_count,
    SUM("Volume"::double precision) AS total_volume
FROM public.group_table
WHERE t_stamp BETWEEN :startTime AND :endTime
GROUP BY hour_bucket
ORDER BY hour_bucket ASC;
