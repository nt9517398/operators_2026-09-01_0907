SELECT 
	
	sum("duration"::decimal) 
FROM public.downtime_formply_press

WHERE end_time is not NULL AND
	downtime_formply_press.end_time < :date_to AND
 	downtime_formply_press.start_time >= :date_from