SELECT 
	
	sum("duration"::decimal) 
FROM public.downtime_formply_press
where downtime_formply_press.end_time::date < (current_date - 5) AND
 		downtime_formply_press.start_time::date >= (current_date -6)
