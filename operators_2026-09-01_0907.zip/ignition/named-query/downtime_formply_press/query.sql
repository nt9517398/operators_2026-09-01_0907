
SELECT downtime_formply_press.*
FROM downtime_formply_press
ORDER BY start_time desc