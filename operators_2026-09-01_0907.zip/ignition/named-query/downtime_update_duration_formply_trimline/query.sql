UPDATE downtime_formply_trimline
SET duration = (EXTRACT(EPOCH FROM end_time::timestamp - start_time::timestamp)/60)::decimal(16,2)
WHERE start_time = (select max(start_time) from downtime_formply_trimline);

UPDATE downtime_formply_trimline
SET sub_area = 'Reason Not Given'
WHERE sub_area IS NULL;

UPDATE downtime_formply_trimline
SET fault = 'Reason Not Given'
WHERE fault IS NULL;