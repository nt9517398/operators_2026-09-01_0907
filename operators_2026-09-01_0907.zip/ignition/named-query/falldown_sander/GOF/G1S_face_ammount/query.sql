SELECT count(*)
FROM public.falldown_sander
WHERE t_stamp::date = CURRENT_DATE
  AND shift = :shift
  AND product = :product
  AND grade = :grade
  AND thickness = :thickness
  AND lathe_g1s_face  = 1
  AND rating = :rating
  AND construction = :construction
  AND run_number = :run_number;