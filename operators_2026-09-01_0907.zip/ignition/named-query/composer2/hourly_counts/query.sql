SELECT
    date_trunc('hour', t_stamp) AS hour_bucket,
    COUNT("FullSheetNumber") AS total_sheets
FROM public.group_table
WHERE t_stamp BETWEEN :startTime AND :endTime
GROUP BY hour_bucket
ORDER BY hour_bucket ASC;




