select
 case
         when t_stamp::time >= '05:00' and t_stamp::time < '06:00' then 5
         when t_stamp::time >= '06:00' and t_stamp::time < '07:00' then 6
         when t_stamp::time >= '07:00' and t_stamp::time < '08:00' then 7
         when t_stamp::time >= '08:00' and t_stamp::time < '09:00' then 8
         when t_stamp::time >= '09:00' and t_stamp::time < '10:00' then 9
         when t_stamp::time >= '10:00' and t_stamp::time < '11:00' then 10
		 when t_stamp::time >= '11:00' and t_stamp::time < '12:00' then 11
		 when t_stamp::time >= '12:00' and t_stamp::time < '13:00' then 12
		 when t_stamp::time >= '13:00' and t_stamp::time < '14:00' then 13
		 when t_stamp::time >= '14:00' and t_stamp::time < '15:00' then 14
		 when t_stamp::time >= '15:00' and t_stamp::time < '16:00' then 15
		 when t_stamp::time >= '16:00' and t_stamp::time < '17:00' then 16
		 when t_stamp::time >= '17:00' and t_stamp::time < '18:00' then 17
		 when t_stamp::time >= '18:00' and t_stamp::time < '19:00' then 18
		 when t_stamp::time >= '19:00' and t_stamp::time < '20:00' then 19
		 when t_stamp::time >= '20:00' and t_stamp::time < '21:00' then 20
		 when t_stamp::time >= '21:00' and t_stamp::time < '22:00' then 21
		 when t_stamp::time >= '22:00' and t_stamp::time < '23:00' then 22
		 when t_stamp::time >= '23:00' and t_stamp::time < '24:00' then 23
		 when t_stamp::time >= '00:00' and t_stamp::time < '01:00' then 00
		 when t_stamp::time >= '01:00' and t_stamp::time < '02:00' then 01
		 when t_stamp::time >= '02:00' and t_stamp::time < '03:00' then 02
		 when t_stamp::time >= '03:00' and t_stamp::time < '04:00' then 03
		 when t_stamp::time >= '04:00' and t_stamp::time < '05:00' then 04 
 end as onehour, 
       sum("Volume"::decimal) as n
from group_table
WHERE
			t_stamp <=  :date_to
		AND t_stamp >=  :date_from
group by onehour
order by onehour asc