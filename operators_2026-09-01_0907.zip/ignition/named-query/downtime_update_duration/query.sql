UPDATE downtime_debarker
SET duration = (EXTRACT(EPOCH FROM end_time::timestamp - start_time::timestamp)/60)::decimal(16,2)
WHERE start_time = (select max(start_time) from downtime_debarker);

UPDATE downtime_debarker
SET area = 'Reason Not Given'
WHERE area IS NULL;

UPDATE downtime_debarker
SET sub_area = 'Reason Not Given'
WHERE sub_area IS NULL;

UPDATE downtime_debarker
SET responsibility = 'Not Defined'
WHERE responsibility IS NULL;

UPDATE downtime_debarker
SET equipment = 'Reason Not Given'
WHERE equipment IS NULL;

UPDATE downtime_debarker
SET action = 'Reason Not Given'
WHERE action IS NULL;