SELECT downtime_composer2.*
FROM downtime_composer2
ORDER BY start_time desc