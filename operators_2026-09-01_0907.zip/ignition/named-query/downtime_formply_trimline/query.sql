
SELECT downtime_formply_trimline.*
FROM downtime_formply_trimline
ORDER BY start_time desc