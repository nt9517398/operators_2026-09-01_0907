SELECT 
	
	sum("duration"::decimal) 
FROM public.downtime_debarker

WHERE end_time is not NULL AND
	downtime_debarker.end_time < :date_to AND
 	downtime_debarker.start_time >= :date_from