SELECT time_stamp

FROM public.group_table_debarker 
WHERE time_stamp >= current_date 
ORDER BY time_stamp desc
limit 1
