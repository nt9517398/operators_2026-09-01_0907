SELECT time_stamp

FROM public.group_table_debarker 
WHERE time_stamp >= (current_date - INTEGER '1')
ORDER BY time_stamp asc
limit 1
