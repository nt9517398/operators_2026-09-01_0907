SELECT 
	count("LogNumber") 

FROM group_table_debarker

WHERE group_table_debarker.time_stamp < :date_to AND
  group_table_debarker.time_stamp >= :date_from