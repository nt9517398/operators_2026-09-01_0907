
SELECT 
 count("Stand")
FROM group_table_debarker
WHERE group_table_debarker."Stand" = 4 AND 
		time_stamp <  :date_to 
		AND time_stamp >=  :date_from