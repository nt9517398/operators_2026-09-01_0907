def onStartup(session):
	
